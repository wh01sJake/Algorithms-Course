package Week4;

import java.util.ArrayList;
import java.util.List;

public class CoffeeMachineApp {
    public static void main(String[] args) {
        Coffee c1 = new Cappuccino();
        System.out.println(c1.toString());
      List <Integer> list1 = new ArrayList<Integer>();
      list1.add(1);
      list1.add(2);


    }
}
